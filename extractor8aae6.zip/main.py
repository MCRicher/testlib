from yt_dlp import YoutubeDL
import os
import sys
import json


def make_cache_dir(library_path):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if not library_path:
        cache_dir = os.path.join(current_dir, ".cache")
    else:
        cache_dir = os.path.join(library_path, ".cache")

    # 判断目录是否存在
    if not os.path.exists(cache_dir):
        # 如果目录不存在，创建目录
        os.makedirs(cache_dir)
        # 设置权限为可读写（仅当前用户）
        os.chmod(cache_dir, 0o700)
        print(f"cache dir '{cache_dir}' created.")
    else:
        print(f"cache dir '{cache_dir}' already exists.")

    return cache_dir


def process_cookie(cookie_str):
    # 检查输入是否为空或只有一行
    if not cookie_str.strip() or len(cookie_str.splitlines()) <= 1:
        return ""  # 输出空字符串
    else:
        # 分割字符串为行，忽略第一行
        lines = cookie_str.splitlines()[1:]

        # 初始化 cookie 字符串
        cookie_string = ""

        # 遍历每一行并提取 key 和 value
        for line in lines:
            parts = line.split("\t")
            if len(parts) >= 3:  # 保证有至少 3 个部分
                key = parts[-2]  # 倒数第二个是 key
                value = parts[-1]  # 倒数第一个是 value
                cookie_string += f"{key}={value}; "

        # 去掉最后一个多余的分号和空格
        cookie_string = cookie_string.strip("; ")
        return cookie_string


def isCookieLangEsRegion(cookie_string):
    # 将 cookie 字符串分割成单独的 cookie
    cookies = cookie_string.split(';')

    # 遍历所有 cookie 查找 lang 参数
    for cookie in cookies:
        cookie = cookie.strip()  # 移除空白字符
        if cookie.startswith('lang='):
            # 提取语言值
            lang_value = cookie[5:]  # 去掉 'lang=' 前缀
            # 检查是否以 'es' 开头
            return lang_value.startswith('es')

    return False


def read_language_cache():
    # 获取当前文件所在的目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, ".cache_lang")

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            print(f'lang cache is: {content}')
        return content
    except FileNotFoundError:
        print(".cache_lang not exists")
        return None
    except Exception as e:
        print(f'read language cache error: {str(e)}')
        return None


def extract(url, cookie_str, json_param_str, library_path):
    print(f"extract from python: {url}")
    print(f"param: {json_param_str}")
    print(f"cookie: {cookie_str}")
    result = ""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # 遍历当前目录及其所有子目录
        for root, dirs, files in os.walk(current_dir):
            if root not in sys.path:  # 避免重复添加
                sys.path.append(root)

        cache_dir = make_cache_dir(library_path)
        cookie_string = process_cookie(cookie_str)
        # 15秒超时时间
        socket_timeout = 15
        print(f"cookie_string: {cookie_string}")
        if isCookieLangEsRegion(cookie_string):
            print("Es region! Skip!")
            return result

        language_cache = read_language_cache()
        if language_cache:
            if language_cache.startswith('es'):
                return result

        # 配置下载选项，只解析不下载
        ydl_opts = {
            'socket_timeout': socket_timeout,
            'format': (
                "bv*[height<=1080]"
                "[protocol!=m3u8_native][protocol!=m3u8][protocol!=http_dash_segments]"
                "[protocol!=f4m][protocol!=ism]"
                "+ba[protocol!=m3u8_native][protocol!=m3u8][protocol!=http_dash_segments]"
                "[protocol!=f4m][protocol!=ism]"
            ),
            'quiet': True,  # 禁用其他输出
            'dumpjson': True,  # 输出解析后的 JSON 数据
            'cachedir': cache_dir,  # 设置缓存目录为当前脚本所在目录
            'noplaylist': True,  # 仅处理单个视频，不处理播放列表
            'http_headers': {
                'Cookie': cookie_string,  # 设置 HTTP 请求的 Cookie
            },
        }
        # 执行解析，获取下载链接
        with YoutubeDL(ydl_opts) as ydl:
            try:
                info_dict = ydl.extract_info(url, download=False)  # 提取信息而不下载
                # 输出所有格式的下载链接
                result = json.dumps(info_dict, indent=4)
                for format_info in info_dict.get('formats', []):
                    print(format_info.get('url'))
                    # 可能引发异常的代码

            except Exception as e:
                # 异常处理代码
                print(f"An error occurred: {e}")
    except Exception as e:
        print(f"Error: {e}")

    return result


if __name__ == '__main__':
    url = "https://www.youtube.com/watch?v=T4SimnaiktU"
    cookie_str = ""
    extract(url, cookie_str,"", None)
