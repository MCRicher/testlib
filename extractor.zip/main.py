from yt_dlp import YoutubeDL
import os
import sys
import json


def extract(url, cookie_str, json_param_str):
    print(f"extract from python: ${url}")
    print(f"cookie: ${cookie_str}")
    print(f"param: ${json_param_str}")
    result = ""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 遍历当前目录及其所有子目录
    for root, dirs, files in os.walk(current_dir):
        if root not in sys.path:  # 避免重复添加
            sys.path.append(root)

    # 配置下载选项，只解析不下载
    ydl_opts = {
        'format': 'bestaudio/best',  # 选择最佳音频格式
        'extractaudio': True,  # 提取音频
        'audioformat': 'mp3',  # 转换为 MP3 格式
        'audioquality': '0',  # 最佳音质
        'quiet': True,  # 禁用其他输出
        'dumpjson': True,  # 输出解析后的 JSON 数据
    }
    # 执行解析，获取下载链接
    with YoutubeDL(ydl_opts) as ydl:
        try:
            info_dict = ydl.extract_info(url, download=False)  # 提取信息而不下载
            # 输出所有格式的下载链接
            result = json.dumps(info_dict, indent=4)
            for format_info in info_dict.get('formats', []):
                print(format_info.get('url'))
                # 可能引发异常的代码

        except Exception as e:
            # 异常处理代码
            print(f"An error occurred: {e}")

    # 设置超时时间为 5 秒
    timeout = 5

    return result
