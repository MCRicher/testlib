"""在禁止 fork/exec 的 iOS 进程内近似一小部分 ``subprocess`` API。

安装后会进程级替换 ``Popen/run/call/check_call/check_output``。命令不会启动子进程：
JS 意图转给 JS evaluator，可选 FFmpeg 意图转给 runner，其它外部程序返回 ENOENT。
这是面向 yt-dlp 当前调用形状的近似层，并非完整 subprocess 兼容实现。

``ThreadPopen`` 只在 ``communicate`` 中启动同进程 daemon worker；单独 ``wait``
（从而当前 ``call/check_call``）不一定 dispatch。超时/``kill`` 只能标记 returncode，
不能终止线程或已进入的 Swift runner，worker 后续还可能覆盖 returncode。``cwd``、
``env`` 和 stdio 对象会保存但不会影响 dispatch。

monkey patch 没有恢复入口；仅删除 ``sys.modules`` 项不等于撤销已经替换的标准库
属性。安装标记无锁，首次并发安装可能竞态。
"""

from __future__ import annotations

import errno
import os
import shlex
import subprocess
import sys
import threading
from typing import Any

from ios_ffmpeg_evaluator import is_ffmpeg_program
from ios_js_evaluator import (
    _normalize_program_name,
    clean_js_runtime_stderr,
    evaluate_javascript,
    evaluate_script_file,
    fake_version_output,
    is_ios_platform,
    is_js_runtime_name,
    is_js_stdin_execution,
    is_quickjs_script_execution,
    is_version_probe,
)
from ios_debug_log import log, log_preview

# 保存原 Popen 仅供诊断/历史引用；当前没有 unapply，且其余四个原函数未保存。
_HOOK_INSTALLED = False
_ORIGINAL_POPEN = subprocess.Popen


def _as_text(data: bytes | str | None, text_mode: bool) -> bytes | str:
    """按近似 Popen 文本模式规范化输出值。

    Args:
        data: bytes、字符串或空值。
        text_mode: 真值要求字符串，假值要求 bytes。

    Returns:
        与模式对应的空值/解码/编码结果；已匹配类型原样返回。

    Side Effects:
        无；转换使用 UTF-8 replacement，不读取实例 encoding/errors 字段。
    """
    if data is None:
        return '' if text_mode else b''
    if text_mode and isinstance(data, bytes):
        return data.decode('utf-8', errors='replace')
    if not text_mode and isinstance(data, str):
        return data.encode('utf-8', errors='replace')
    return data


def _normalize_argv(args: Any, shell: bool) -> list[str]:
    """把 subprocess args 转为内部字符串列表。

    Args:
        args: 命令字符串或参数 iterable。
        shell: 是否按 shell 调用形状处理。

    Returns:
        shell 模式下为单个命令字符串；普通字符串用 ``shlex.split``，其它 iterable
        各项字符串化。

    Raises:
        ValueError: shlex 无法解析字符串。
        TypeError: 非字符串且不可迭代。

    Side Effects:
        无。shell 模式随后仍会被 dispatch 拒绝。
    """
    if shell:
        if isinstance(args, (list, tuple)):
            command = ' '.join(str(part) for part in args)
        else:
            command = str(args)
        return [command]
    if isinstance(args, str):
        return shlex.split(args)
    return [str(part) for part in args]


def _basename(argv: list[str]) -> str:
    """取得规范化 argv[0] basename。

    Args:
        argv: 内部参数列表。

    Returns:
        空列表返回空字符串，否则返回去路径、规范大小写/后缀后的程序名。

    Side Effects:
        无。
    """
    if not argv:
        return ''
    return _normalize_program_name(os.path.basename(argv[0]))


def _dispatch_command(
    argv: list[str],
    *,
    stdin_data: bytes | str | None,
    shell: bool,
    text_mode: bool,
) -> tuple[bytes | str, bytes | str, int]:
    """在当前 worker 线程路由一个受支持的命令意图。

    Args:
        argv: 已规范化参数列表。
        stdin_data: communicate 输入。
        shell: shell 请求标记；iOS 路径一律拒绝。
        text_mode: 控制 stdout/stderr 返回 bytes 或字符串。

    Returns:
        ``(stdout, stderr, returncode)`` subprocess 风格三元组。

    Raises:
        OSError: shell/空命令、不支持的外部程序、无 JS 输入或不兼容 npm 探测；
            FFmpeg bridge 的 OSError 也原样传播。
        Exception: JS evaluator/脚本读取异常原样传播。FFmpeg 的非 OSError 异常会
            转换为 returncode 1 与 stderr。

    Side Effects:
        可能同步执行当前确认注册的 JS runner、可选 FFmpeg runner或读取脚本文件，
        并写共享日志。Deno/Bun npm import 探测被显式拒绝。
    """
    if shell:
        raise OSError(
            errno.ENOTSUP,
            'iOS does not support shell subprocess execution',
        )

    if not argv:
        raise OSError(errno.ENOENT, 'empty command')

    program = _basename(argv)

    if is_js_runtime_name(program) and is_version_probe(argv):
        log('subprocess_hook', f'JS version probe argv={argv}')
        version = fake_version_output(program)
        if version is None:
            raise OSError(errno.ENOENT, f'unknown JS runtime probe: {program}')
        stdout = _as_text(version, text_mode)
        return stdout, _as_text('', text_mode), 0

    if is_js_stdin_execution(argv):
        log('subprocess_hook', f'JS stdin execution argv={argv}')
        if stdin_data is None:
            raise OSError(errno.EINVAL, 'JS runtime stdin execution requires input')
        source = stdin_data.decode('utf-8') if isinstance(stdin_data, bytes) else str(stdin_data)
        # 此类 npm import 不能由当前 JavaScriptCore 合同执行，促使上层更换 provider。
        if "import('npm:" in source or 'import("npm:' in source:
            log('subprocess_hook', 'rejecting Deno/Bun npm probe script for JSC')
            raise OSError(
                errno.ENOTSUP,
                'iOS JavaScriptCore cannot execute Deno npm import scripts',
            )
        stdout, stderr = evaluate_javascript(source)
        stderr = clean_js_runtime_stderr(stderr)
        return _as_text(stdout, text_mode), _as_text(stderr, text_mode), 0

    if is_quickjs_script_execution(argv):
        log('subprocess_hook', f'quickjs --script argv={argv}')
        script_path = argv[2]
        stdout, stderr = evaluate_script_file(script_path)
        stderr = clean_js_runtime_stderr(stderr)
        return _as_text(stdout, text_mode), _as_text(stderr, text_mode), 0

    if is_ffmpeg_program(program):
        try:
            from ios_ffmpeg_bridge import execute_via_bridge, is_bridge_available

            if is_bridge_available():
                log('subprocess_hook', f'ffmpeg bridge argv={argv}')
                stdout, stderr, returncode = execute_via_bridge(argv, stdin_data)
                return _as_text(stdout, text_mode), _as_text(stderr, text_mode), returncode
        except OSError:
            raise
        except Exception as exc:  # noqa: BLE001
            log('subprocess_hook', f'ffmpeg bridge failed: {exc}')
            stderr = _as_text(str(exc), text_mode)
            return _as_text('', text_mode), stderr, 1

    log('subprocess_hook', f'external command blocked argv={argv}')
    raise OSError(
        errno.ENOENT,
        f'iOS cannot execute external program: {argv[0]}',
    )


class ThreadPopen:
    """由 ``communicate`` 驱动的同进程线程近似层。

    构造函数不会启动工作；首次且唯一一次 ``communicate`` 才创建名为
    ``ios-subprocess-hook`` 的 daemon thread。``wait`` 只等待已经存在的 worker，
    因此未 communicate 时返回 0 而不 dispatch，也不设置 ``returncode``。

    ``kill``/超时无法强制终止 Python 线程或宿主 runner，只将 ``_killed`` 和
    ``returncode=-9`` 写入实例；仍在运行的 worker 完成后可能覆盖该值。对象只在
    ``_wait_lock`` 下协调自身方法，不提供完整 Popen 管道、信号、cwd/env 语义。
    """

    def __init__(
        self,
        args,
        bufsize=-1,
        executable=None,
        stdin=None,
        stdout=None,
        stderr=None,
        preexec_fn=None,
        close_fds=True,
        shell=False,
        cwd=None,
        env=None,
        universal_newlines=None,
        startupinfo=None,
        creationflags=0,
        restore_signals=True,
        start_new_session=False,
        pass_fds=(),
        *,
        user=None,
        group=None,
        extra_groups=None,
        encoding=None,
        errors=None,
        text=None,
        umask=-1,
        pipesize=-1,
        process_group=None,
    ):
        """保存 Popen 风格参数并初始化尚未 dispatch 的状态。

        Args:
            args: 命令及参数。
            shell: shell 请求，稍后 dispatch 时会被拒绝。
            cwd/env/stdin/stdout/stderr: 为接口形状保存，但不改变实际 dispatch。
            universal_newlines/encoding/errors/text: 共同决定简化的文本模式。
            其余参数: 为兼容调用签名接收后丢弃。

        Raises:
            参数规范化失败时传播 ``shlex``/迭代异常。

        Side Effects:
            无线程、子进程或 runner 调用；``pid`` 设为当前进程 ID。
        """
        del (
            bufsize, executable, preexec_fn, close_fds, startupinfo, creationflags,
            restore_signals, start_new_session, pass_fds, user, group, extra_groups,
            umask, pipesize, process_group,
        )

        self.args = args
        self.shell = shell
        self.cwd = cwd
        self.env = env
        self.stdin = stdin
        self.stdout = stdout
        self.stderr = stderr
        self.text = bool(text or universal_newlines or encoding or errors)
        self.encoding = encoding or ('utf-8' if self.text else None)
        self.errors = errors or 'replace'

        self.returncode: int | None = None
        self.pid = os.getpid()
        self._argv = _normalize_argv(args, shell)
        self._stdin_data: bytes | str | None = None
        self._stdout_data: bytes | str = _as_text(b'', self.text)
        self._stderr_data: bytes | str = _as_text(b'', self.text)
        self._wait_lock = threading.Lock()
        self._communication_started = False
        self._worker: threading.Thread | None = None
        self._killed = False
        self._worker_error: BaseException | None = None

    def __enter__(self):
        """返回自身，不启动 worker。"""
        return self

    def __exit__(self, exc_type, exc, tb):
        """调用 ``wait`` 收尾，但不会因此启动尚未 dispatch 的命令。"""
        self.wait()

    def _run_worker(self, input_data: bytes | str | None) -> None:
        """在线程中执行路由并保存结果或异常。

        Args:
            input_data: communicate 输入。

        Side Effects:
            调用 ``_dispatch_command``，无锁写实例结果。OSError 映射为 127，其它
            BaseException 映射为 1；finally 将 ``_worker`` 清空。异常留待
            communicate 线程重新抛出。
        """
        try:
            stdout, stderr, returncode = _dispatch_command(
                self._argv,
                stdin_data=input_data,
                shell=self.shell,
                text_mode=self.text,
            )
            self._stdout_data = stdout
            self._stderr_data = stderr
            self.returncode = returncode
        except BaseException as exc:
            self._worker_error = exc
            if isinstance(exc, OSError):
                self.returncode = 127
            else:
                self.returncode = 1
        finally:
            self._worker = None

    def _start_worker(self, input_data: bytes | str | None) -> threading.Thread:
        """创建并启动 daemon dispatch 线程。

        Args:
            input_data: 传给 worker 的输入。

        Returns:
            已启动线程对象。

        Side Effects:
            写 ``_worker`` 并启动同进程线程；不复制 thread-local task 状态。
        """
        worker = threading.Thread(
            target=self._run_worker,
            args=(input_data,),
            name='ios-subprocess-hook',
            daemon=True,
        )
        self._worker = worker
        worker.start()
        return worker

    def communicate(self, input=None, timeout=None):
        """唯一会保证首次 dispatch 的 Popen 近似入口。

        Args:
            input: 传给命令路由的 bytes/字符串。
            timeout: 等待 worker 的秒数；``None`` 表示无限等待。

        Returns:
            缓存的 ``(stdout, stderr)``。

        Raises:
            ValueError: 第二次调用 communicate。
            subprocess.TimeoutExpired: worker 超时；线程仍可能继续运行。
            BaseException: worker 捕获的原异常重新抛出。

        Side Effects:
            在实例锁内启动并 join daemon worker。若已 kill 且尚未启动则直接返回空
            缓存；超时会调用 ``kill``，但不能停止线程或宿主工作。
        """
        with self._wait_lock:
            if self._communication_started:
                raise ValueError('communicate() already called')
            self._communication_started = True

            if self._killed:
                return self._stdout_data, self._stderr_data

            worker = self._start_worker(input)
            worker.join(timeout)
            if worker.is_alive():
                self.kill()
                raise subprocess.TimeoutExpired(self.args, timeout)

            if self._worker_error is not None:
                raise self._worker_error

            return self._stdout_data, self._stderr_data

    def wait(self, timeout=None):
        """等待已存在的 worker；不会自行 dispatch。

        Args:
            timeout: 已启动 worker 的 join 超时。

        Returns:
            已有 returncode；没有 worker 且尚无 returncode 时直接返回 0。

        Raises:
            subprocess.TimeoutExpired: 已有 worker 超时；底层线程仍可能继续。

        Side Effects:
            可能 join/标记 kill。单独调用（包括当前 ``call``）不执行命令。
        """
        with self._wait_lock:
            if self.returncode is not None:
                return self.returncode
            if self._worker is not None:
                self._worker.join(timeout)
                if self._worker.is_alive():
                    self.kill()
                    raise subprocess.TimeoutExpired(self.args, timeout)
            return self.returncode if self.returncode is not None else 0

    def poll(self):
        """读取 worker/returncode 的瞬时状态。

        Returns:
            worker 活跃时为 ``None``，否则返回当前 ``returncode``，可能仍为 None。

        Side Effects:
            仅获取实例锁；不会启动或等待工作。
        """
        with self._wait_lock:
            if self._worker is not None and self._worker.is_alive():
                return None
            return self.returncode

    def kill(self, timeout=0):
        """标记实例已 kill，但不能终止同进程线程。

        Args:
            timeout: 为签名兼容接收并忽略。

        Returns:
            ``None``。

        Side Effects:
            设置 ``_killed=True`` 与 ``returncode=-9``。活跃 worker/宿主 runner 继续
            执行，且完成后可能写回其它 returncode。
        """
        del timeout
        self._killed = True
        self.returncode = -9
        if self._worker is not None and self._worker.is_alive():
            # Python 无法强制终止同进程线程；这里只保留 kill 状态。
            pass

    def terminate(self):
        """调用 ``kill`` 的同义近似；同样不会终止 worker。"""
        self.kill()


def _make_run():
    """创建替代 ``subprocess.run`` 的闭包。

    Returns:
        通过 ``communicate`` 保证 dispatch，并返回 ``CompletedProcess`` 的函数。

    Side Effects:
        无，直到返回的闭包被调用。
    """
    def run(*popenargs, input=None, capture_output=False, timeout=None, check=False, **kwargs):
        """以 ThreadPopen communicate 执行一次命令近似。"""
        if capture_output:
            kwargs['stdout'] = subprocess.PIPE
            kwargs['stderr'] = subprocess.PIPE
        with ThreadPopen(*popenargs, **kwargs) as process:
            try:
                stdout, stderr = process.communicate(input, timeout=timeout)
            except subprocess.TimeoutExpired as exc:
                process.kill()
                raise exc
            retcode = process.poll()
            if check and retcode:
                raise subprocess.CalledProcessError(retcode, process.args, output=stdout, stderr=stderr)
        return subprocess.CompletedProcess(process.args, retcode, stdout, stderr)

    return run


def _make_call():
    """创建当前仅调用 ``wait`` 的 ``subprocess.call`` 近似。

    Returns:
        闭包。由于 ThreadPopen 构造不启动 worker，该闭包通常不 dispatch 并返回 0。
    """
    def call(*popenargs, timeout=None, **kwargs):
        """构造 ThreadPopen 后直接 wait；不保证执行命令。"""
        with ThreadPopen(*popenargs, **kwargs) as process:
            return process.wait(timeout=timeout)

    return call


def _make_check_call():
    """创建建立在当前 ``call`` 近似上的 ``check_call``。

    Returns:
        闭包；只有底层返回非零才抛错，但底层未必 dispatch。
    """
    def check_call(*popenargs, **kwargs):
        """调用当前 call 近似并按非零 returncode 抛 CalledProcessError。"""
        retcode = _make_call()(*popenargs, **kwargs)
        if retcode:
            cmd = kwargs.get('args')
            if cmd is None:
                cmd = popenargs[0]
            raise subprocess.CalledProcessError(retcode, cmd)
        return 0

    return check_call


def _make_check_output():
    """创建通过 ``run``/``communicate`` dispatch 的 ``check_output`` 近似。"""
    def check_output(*popenargs, timeout=None, **kwargs):
        """强制捕获 stdout 并返回；不会自动启用 check=True。"""
        kwargs['stdout'] = subprocess.PIPE
        return _make_run()(*popenargs, timeout=timeout, **kwargs).stdout

    return check_output


def should_enable_ios_subprocess_hook(force: bool | None = None) -> bool:
    """判断是否应替换标准库 subprocess 符号。

    Args:
        force: 非 ``None`` 时直接采用；否则检查平台标识。

    Returns:
        强制值或 iOS 平台判断结果。

    Side Effects:
        无；不检查任何 runner 是否注册。
    """
    if force is not None:
        return force
    return is_ios_platform()


def apply_ios_subprocess_hook(force: bool | None = None) -> bool:
    """幂等安装进程级 subprocess monkey patch。

    Args:
        force: 安装平台判断覆盖值。

    Returns:
        已安装/安装成功时为 ``True``；平台判断拒绝时为 ``False``。

    Side Effects:
        替换标准库模块五个公开属性并设置无锁全局标记，影响同进程所有代码。
        没有恢复 API；``_ORIGINAL_POPEN`` 虽保存但不会自动使用，删除模块缓存也不
        会还原标准库对象上的属性。
    """
    global _HOOK_INSTALLED

    if _HOOK_INSTALLED:
        return True
    if not should_enable_ios_subprocess_hook(force):
        return False

    subprocess.Popen = ThreadPopen  # type: ignore[assignment,misc]
    subprocess.run = _make_run()
    subprocess.call = _make_call()
    subprocess.check_call = _make_check_call()
    subprocess.check_output = _make_check_output()

    from ios_debug_log import log

    log('subprocess_hook', 'apply_ios_subprocess_hook installed')
    _HOOK_INSTALLED = True
    return True


def is_hook_installed() -> bool:
    """读取 subprocess hook 安装标记。

    Returns:
        安装函数完成时为 ``True``。

    Side Effects:
        无。不校验标准库属性是否后来被其它代码覆盖。
    """
    return _HOOK_INSTALLED
