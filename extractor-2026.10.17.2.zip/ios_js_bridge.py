"""Swift runner 与 Python JavaScript 调用方之间的同步桥接合同。

OfflinePro 宿主只注册 ``__main__.execute_javascript``（见 ``PythonExtractor``），
**不会**调用本模块的 ``register_runner``。解析前须调用
``ensure_legacy_execute_javascript_runner()``，把 EJS/subprocess 需要的 runner
接到该遗留入口（用 console.log 包装，兼容 EJS 输出约定）。

若其它宿主已 ``register_runner``，则不再覆盖。
``ios_ejs_hook`` 与 ``ios_subprocess_hook`` 会经本模块同步执行 JavaScript。
runner 和日志均为进程级无锁状态，调用方需自行满足线程/队列约束。

注意：``log_preview`` 只截断、不脱敏，传入本模块的源码或结果不应包含可识别的
凭据、完整私有 URL、绝对路径、标题或动态媒体元数据。
"""

from __future__ import annotations

from ios_debug_log import log, log_preview

# 进程级 runner 引用；注册/注销/读取均无锁，调用期间可能与替换操作竞态。
_RUNNER = None


def _legacy_execute_javascript_runner(source: str):
    """经 OfflinePro ``__main__.execute_javascript`` 跑 JS，并适配 EJS 的 console.log 输出。"""
    import __main__

    exec_js = getattr(__main__, 'execute_javascript', None)
    if exec_js is None or not callable(exec_js):
        raise RuntimeError(
            '__main__.execute_javascript not registered. '
            'PythonExtractor.registerPythonJavascriptBridge must run before extract.'
        )
    # 宿主 evaluateScript 返回最后表达式；EJS 约定写 console.log → 包装后取回字符串。
    wrapped = (
        '(function(){\n'
        "var __ios_js_out='';\n"
        'var console={log:function(){'
        "__ios_js_out=Array.prototype.slice.call(arguments).map(String).join(' ');"
        '}};\n'
        f'{source}\n'
        ';return __ios_js_out;\n'
        '})();'
    )
    result = exec_js(wrapped)
    return str(result or ''), ''


def ensure_legacy_execute_javascript_runner() -> bool:
    """若尚未 register_runner，则挂上 OfflinePro 遗留 ``execute_javascript``。

    Returns:
        安装后或已有 runner 时为 True；无法挂载时为 False。
    """
    if is_bridge_available():
        return True
    try:
        import __main__

        if not callable(getattr(__main__, 'execute_javascript', None)):
            log('js_bridge', 'legacy execute_javascript missing; cannot install fallback runner')
            return False
        register_runner(_legacy_execute_javascript_runner)
        log('js_bridge', 'legacy __main__.execute_javascript runner installed')
        return True
    except Exception as exc:  # noqa: BLE001
        log('js_bridge', f'legacy runner install failed: {exc}')
        return False


def register_runner(runner) -> None:
    """注册宿主 JavaScript runner。

    Args:
        runner: callable，合同为 ``runner(source: str) -> (stdout, stderr) | str``。

    Returns:
        ``None``。

    Raises:
        TypeError: runner 为空或不可调用。

    Side Effects:
        无锁替换进程级 ``_RUNNER`` 并写诊断日志。后续执行发生在调用线程。
    """
    global _RUNNER
    if runner is None or not callable(runner):
        raise TypeError('runner must be callable')
    _RUNNER = runner
    log('js_bridge', 'JS runner registered')


def unregister_runner() -> None:
    """清除当前 JavaScript runner。

    Returns:
        ``None``。

    Side Effects:
        无锁清空 ``_RUNNER`` 并写日志；不会撤销 EJS/subprocess monkey patch，
        也不会取消已经进入 runner 的同步调用。
    """
    global _RUNNER
    _RUNNER = None
    log('js_bridge', 'Swift JS runner unregistered')


def is_bridge_available() -> bool:
    """返回当前时刻是否持有 runner。

    Returns:
        ``_RUNNER`` 非空时为 ``True``。

    Side Effects:
        无。结果只是无锁瞬时状态，不保证紧随其后的调用仍使用同一 runner。
    """
    return _RUNNER is not None


def evaluate_via_bridge(source: str) -> tuple[str, str]:
    """在当前线程同步调用宿主 runner 并规范化输出。

    Args:
        source: 非空 JavaScript 源码。

    Returns:
        ``(stdout, stderr)`` 字符串二元组。runner 返回 list/tuple 时读取前两项；
        其他返回值整体字符串化并作为 stdout。

    Raises:
        RuntimeError: runner 未注册或源码为空。
        Exception: 宿主 runner 抛出的其他异常原样传播。

    Side Effects:
        同步执行宿主代码并写共享日志。预览只限长、不脱敏；本函数没有取消、
        超时或线程切换机制。
    """
    log('js_bridge', f'evaluate_via_bridge called bridge_available={is_bridge_available()}')
    if _RUNNER is None:
        raise RuntimeError(
            'Swift JS runner not registered. '
            'PythonMediaExtractor must call ios_js_bridge.register_runner during prepare().'
        )
    if not source or not str(source).strip():
        raise RuntimeError('empty JavaScript source')

    log_preview('js_bridge', 'JS source', source)
    try:
        result = _RUNNER(source)
    except Exception as exc:  # noqa: BLE001
        log('js_bridge', f'Swift runner raised: {exc}')
        raise

    if isinstance(result, (list, tuple)):
        stdout = result[0] if len(result) > 0 else ''
        stderr = result[1] if len(result) > 1 else ''
        log_preview('js_bridge', 'JS stdout', str(stdout or ''))
        if stderr:
            log_preview('js_bridge', 'JS stderr', str(stderr))
        if not stdout:
            log('js_bridge', 'WARNING: Swift runner returned empty stdout (EJS may have failed)')
        return str(stdout or ''), str(stderr or '')
    log_preview('js_bridge', 'JS result', str(result))
    if not result:
        log('js_bridge', 'WARNING: Swift runner returned empty str (EJS may have failed)')
    return str(result), ''
