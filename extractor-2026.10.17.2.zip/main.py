"""Swift / 旧调用方兼容入口。

真实解析在 ``extract_media``；本模块只做薄转发，并接受历史第 5 参 ``version``（忽略）。
禁止在此改 yt_dlp；业务逻辑只改 ``extract_media.py`` / ``ios_*.py``。
"""

from __future__ import annotations

from extract_media import (  # noqa: F401 — re-export
    check_url_support,
    extract as _extract,
    search,
)


def extract(url, cookie_str="", json_param_str="", library_path="", version=None):
    """兼容 ``PythonExtractor``：``extract(url, cookies, json, cache[, version])``。"""
    return _extract(url, cookie_str, json_param_str, library_path)
