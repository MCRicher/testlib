"""第一方 Python 适配层的进程内诊断日志缓冲区。

日志会同时写入 stderr，并由提取/下载入口放进返回 JSON 的 ``debug_log``。
``_LOGS`` 与 ``_ENABLED`` 是无锁的进程级共享状态：并发任务可能互相清空、
交错或改变开关。调用方不得把该缓冲区当作任务隔离的审计日志。

``log_preview`` 只做换行转义和长度截断，**不会脱敏**；调用方必须在传入前
避免 Cookie、凭据、完整私有 URL、绝对路径、标题或动态媒体元数据。
"""

from __future__ import annotations

import sys
import time

# 无锁共享缓冲区和开关；由所有入口、probe worker 与 bridge 共用。
_LOGS: list[str] = []
_ENABLED = True


def set_enabled(enabled: bool) -> None:
    """启用或禁用后续日志写入。

    Args:
        enabled: 真值允许 ``log`` 追加日志，假值使其立即返回。

    Returns:
        ``None``。

    Side Effects:
        修改进程级 ``_ENABLED``；无锁，可能与并发写入竞态。已有日志不受影响。
    """
    global _ENABLED
    _ENABLED = enabled


def clear_log() -> None:
    """清空当前进程共享的日志列表。

    Returns:
        ``None``。

    Side Effects:
        原地清空 ``_LOGS``。该操作无任务隔离且无锁，并发入口可能清掉彼此日志。
    """
    _LOGS.clear()


# 仅限制回传尾部；超限时 get_log 还会额外返回一条省略提示。
_MAX_LOG_LINES = 300


def get_log() -> list[str]:
    """取得适合放入 JSON 响应的日志快照。

    Returns:
        新列表。未超限时包含全部当前行；超限时包含一条省略说明与最后
        ``_MAX_LOG_LINES`` 行，因此总数最多为该上限加一。

    Side Effects:
        无；但读取无锁，快照可能反映并发追加/清理中的瞬时状态。
    """
    if len(_LOGS) <= _MAX_LOG_LINES:
        return list(_LOGS)
    omitted = len(_LOGS) - _MAX_LOG_LINES
    return [f'[YTDLP-iOS][debug] ... {omitted} earlier log lines omitted ...', *_LOGS[-_MAX_LOG_LINES:]]


def log(category: str, message: str) -> None:
    """按统一模块前缀记录一行诊断信息。

    Args:
        category: 稳定的日志分类，不应包含用户数据。
        message: 已由调用方完成脱敏的摘要文本。

    Returns:
        ``None``。

    Side Effects:
        启用时向无锁 ``_LOGS`` 追加，并尝试同步写入/刷新 stderr；stderr 异常被
        吞掉。日志内容本身不会自动脱敏或截断。
    """
    if not _ENABLED:
        return
    line = f'[YTDLP-iOS][{category}] {message}'
    _LOGS.append(line)
    try:
        sys.stderr.write(line + '\n')
        sys.stderr.flush()
    except Exception:  # noqa: BLE001
        pass


def log_preview(category: str, label: str, text: str, limit: int = 240) -> None:
    """记录文本的限长预览；不执行任何隐私或凭据脱敏。

    Args:
        category: 传给 ``log`` 的分类。
        label: 预览字段标签。
        text: 要预览的文本；调用方必须确保其可安全记录。
        limit: 换行转义后保留的最大字符数，超出时追加省略号。

    Returns:
        ``None``。

    Side Effects:
        通过 ``log`` 修改共享缓冲区并写 stderr。空文本会记录 ``<empty>``。
    """
    if not text:
        log(category, f'{label}: <empty>')
        return
    preview = text.replace('\n', '\\n')
    if len(preview) > limit:
        preview = preview[:limit] + '...'
    log(category, f'{label} len={len(text)} preview={preview}')


class log_timing:
    """同步代码块计时 context manager。

    实例只保存本次计时的局部状态；进入和退出时仍会写入进程共享日志。退出
    方法返回 ``None``，因此不会吞掉业务异常。
    """

    def __init__(self, category: str, action: str):
        """创建尚未开始的计时器。

        Args:
            category: 日志分类。
            action: 操作摘要；不得含敏感或动态媒体数据。

        Side Effects:
            无。开始时间在 ``__enter__`` 中设置。
        """
        self.category = category
        self.action = action
        self._start = 0.0

    def __enter__(self):
        """记录单调时钟起点及开始日志，并返回自身。

        Returns:
            当前 ``log_timing`` 实例。

        Side Effects:
            更新实例 ``_start``，并调用 ``log`` 写共享日志。
        """
        self._start = time.monotonic()
        log(self.category, f'{self.action} start')
        return self

    def __exit__(self, exc_type, exc, tb):
        """记录耗时和成功/失败状态，但不抑制异常。

        Args:
            exc_type: with 块异常类型；无异常时为 ``None``。
            exc: 异常实例。
            tb: traceback 对象。

        Returns:
            ``None``，使原异常继续传播。

        Side Effects:
            读取单调时钟并通过 ``log`` 写入毫秒耗时。
        """
        elapsed_ms = int((time.monotonic() - self._start) * 1000)
        if exc_type is None:
            log(self.category, f'{self.action} done ({elapsed_ms}ms)')
        else:
            log(self.category, f'{self.action} failed ({elapsed_ms}ms): {exc}')
